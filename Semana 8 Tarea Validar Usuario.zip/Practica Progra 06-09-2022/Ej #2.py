#2. Crear un módulo para validación de contraseñas, que cumplirá las siguientes características:

usuario = input ("Ingrese su nombre por favor: ")
print("-------------------------------------------------------")
caracteres = len(usuario)
tipo = usuario.isalnum()
if tipo == True:
    if caracteres > 5:
        print("La contraseña debe tener un minimo de 8 caracteres.")
        print("-------------------------------------------------------")
    elif caracteres < 8:
        print("La contraseña no puede contener mas de 12 caracteres")
        print("-------------------------------------------------------")
    else:
        print("Usuario encontrado")
        print("-------------------------------------------------------")

  
from ast import Num

contraseña = input("Ingrese la contraseña por favor: ")
print("-------------------------------------------------------")

if len(contraseña) < 8:
    print("La contraseña elegida no es segura")
    print("-------------------------------------------------------")


num = False 
for carac in contraseña:
    if carac.isdigit()== True:
        num = True

if contraseña.count(" ") > 0:
    print("La contraseña no puede contener espacios en blanco")
    print("-------------------------------------------------------")
else:
    print("Contraseña valida")
    print("-------------------------------------------------------")
    print("Bienvenid@: ", usuario)
    print("-------------------------------------------------------")


        