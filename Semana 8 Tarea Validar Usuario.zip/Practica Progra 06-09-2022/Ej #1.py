#1. Crear un módulo para validación de nombres de usuarios, que cumplirá las siguientes características:

usuario=input ("Ingrese el nombre de usuario:")
caracteres=len(usuario)
tipo=usuario.isalnum()

if tipo== True:
    if caracteres<6:
        print("El nombre de usuario debe contener al menos 6 caracteres")
    elif caracteres>12:
        print("El nombre de usuario no puede contener más de 12 caracteres ")
    elif usuario.isalnum():
        print ("El nombre de usuario puede contener solo letras y números")
    else:
        print("Bienvenido,usuario")
    
def validar_usuario(self,username):
        valido=self.longitud(username) and self.alfanumerico(username)
        return valido



