#3. Crear un programa que utilice los módulos que ha creado pidiéndole al usuario un usuario y contraseña

usuario=input ("Ingrese el nombre de usuario:")
caracteres=len(usuario)
tipo=usuario.isalnum()

if tipo== True:
    if caracteres<6:
        print("El nombre de usuario debe contener al menos 6 caracteres")
    elif caracteres>12:
        print("El nombre de usuario no puede contener más de 12 caracteres ")
    elif usuario.isalnum():
        print ("El nombre de usuario puede contener solo letras y números")
    else:
        print("Bienvenido,usuario")
    
def validar_usuario(self,username):
        valido=self.longitud(username) and self.alfanumerico(username)
        return valido


from ast import Num
contraseña = input("Ingrese su contraseña: ")
if len(contraseña) < 8:
    print("La contraseña elegida no es segura")

num = False
for carac in contraseña:
    if carac.isdigit()== True:
        num=True

if contraseña.count(" ") > 0:
    print("La contraseña no puede contener espacios en blanco")

else:
    print("Contraseña Valida ")
    print("Bienvenido: ", usuario) 